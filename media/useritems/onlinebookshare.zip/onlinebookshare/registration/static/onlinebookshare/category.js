[
 {
  "id":"1",
  "name":"Educational",
 },
 {
  "id":"2",
  "name":"Scientific",
 },
 {
  "id":"3",
  "name":"Fantasy",

 },
 {
  "id":"4",
  "name":"Literature",

 },
 {
  "id":"5",
  "name":"Detective",

 },
 {
  "id":"6",
  "name":"Horror",

 },
 {
  "id":"7",
  "name":"Travel",

 },
 {
  "id":"8",
  "name":"History",

 },
 {
  "id":"9",
  "name":"Poetry",

 },
 {
  "id":"10",
  "name":"Journals",

 },
 {
  "id":"11",
  "name":"Biography",

 },
 {
  "id":"12",
  "name":"Comics",

 },
 {
  "id":"13",
  "name":"Series",

 },
 {
  "id":"14",
  "name":"Others",
 },
]

